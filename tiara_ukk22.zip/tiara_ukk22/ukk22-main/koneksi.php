<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "tiara_ukk22";

$koneksi = mysqli_connect($host, $user, $pass, $db);
